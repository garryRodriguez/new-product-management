<nav class="navbar navbar-expand-lg bg-secondary text-white">
        
        <div class="container-fluid">
                <div class="col mx-2">
                    <h2 class="display-1"><i class="fa-solid fa-gears"></i> Products-Update</h2>
                </div>
                <div class="col">
                    <ul class="navbar-nav justify-content-end fs-lg">
                         
                    <li class="nav-item">
                         <a href="order-products.php" class="nav-link btn btn-success-outline p-3 fs-3 text-white text-decoration-none"><i class="fa-solid fa-house-user"></i> Home</a>
                    </li>
                    <li class="nav-item">
                         <a href="add-product.php" class="nav-link btn btn-success-outline p-3 fs-3 text-white text-decoration-none"><i class="fa-solid fa-file-circle-plus"></i> Add Product</a>
                    </li>
                    <li class="nav-item">
                         <a href="view-products.php" class="nav-link btn btn-success-outline p-3 fs-3 text-white text-decoration-none"><i class="fa-solid fa-eye"></i> View Products</a>
                    </li>
                    <li class="nav-item">
                         <a href="logout.php" class="nav-link btn btn-success-outline p-3 fs-3 text-white text-decoration-none">Logout <i class="fa-solid fa-right-from-bracket"></i></a>
                    </li>
                    </ul>
                </div>
                
        </div>
</nav>