<nav class="navbar navbar-expand-lg bg-success text-white">
        
        <div class="container-fluid">
                <div class="col">
                <h2 class="display-1"><i class="fa-regular fa-folder-open"></i> Categories</h2>
                </div>
                <div class="col">
                <ul class="navbar-nav justify-content-end fs-lg">
                      
                   <li class="nav-item">
                        <a href="#" class="nav-link text-white text-decoration-none">Home</a>
                   </li>
                   <li class="nav-item">
                        <a href="#" class="nav-link text-white text-decoration-none">Add Product</a>
                   </li>
                   <li class="nav-item">
                        <a href="#" class="nav-link text-white text-decoration-none">View Products</a>
                   </li>
                   <li class="nav-item">
                        <a href="#" class="nav-link text-white text-decoration-none">Logout</a>
                   </li>
                </ul>
                </div>
                
        </div>
</nav>
